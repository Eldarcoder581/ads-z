import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Flag, Ruler, Users, Facebook, Instagram } from "lucide-react"

export default function Component()
\
{
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center bg-white shadow-sm">
        <Link href="#" className="flex items-center justify-center\" prefetch=\{false\}>
          <span className="text-lg font-bold">İNNovativ Təşəbbüslər</span>
          <span className="sr-only">Innovative Initiatives</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-sm font-medium hover:underline underline-offset-4\" prefetch=\{false\}>
            Ana Səhifə
          </Link>
          <Link href="#" className="text-sm font-medium hover:underline underline-offset-4\" prefetch=\{false\}>
            Haqqında
          </Link>
          <Link href="#" className="text-sm font-medium hover:underline underline-offset-4\" prefetch=\{false\}>\
            Layihələr
          </Link>
          <Link href="#" className="text-sm font-medium hover:underline underline-offset-4" prefetch=\{false\}>\
            Tədbirlər
          </Link>
          <Link href="#" className="text-sm font-medium hover:underline underline-offset-4" prefetch=\{false\}>\
            Qalereya
          </Link>
          <Link href="#" className="text-sm font-medium hover:underline underline-offset-4" prefetch=\{false\}>\
            Əlaqə
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="relative w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-r from-[#001f3f] to-[#003366] text-white overflow-hidden">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Hero Background"
            width=\{1920\}\
            height=\{1080\}
            className="absolute inset-0 w-full h-full object-cover opacity-30"
            priority
          />
          <div className="container px-4 md:px-6 relative z-10">
            <div className="flex flex-col items-start space-y-4 text-left">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Yeniliyə açılan qapı: Sosial və Elmi Təşəbbüslər
              </h1>
              <p className="max-w-[600px] text-gray-200 md:text-xl">
                Maarifləndirmə, yaradıcı düşüncə və milli dəyərlərin inkişafı üçün platforma
              </p>
              <Button className="inline-flex h-10 items-center justify-center rounded-md border border-gray-200 bg-white px-8 text-sm font-medium text-gray-900 shadow transition-colors hover:bg-gray-100 hover:text-gray-900 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-gray-950 disabled:pointer-events-none disabled:opacity-50 dark:border-gray-800 dark:bg-gray-950 dark:hover:bg-gray-800 dark:hover:text-gray-50 dark:focus-visible:ring-gray-300">
                Lay helera basın
              </Button>
            </div>
          </div>
        </section>

        <section id="projects" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Layihələr</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Bizim əsas layihələrimiz və təşəbbüslərimiz.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-6 py-12 lg:grid-cols-2 xl:grid-cols-2">
              <Card className="flex flex-col md:flex-row items-center p-4 gap-4">
                <Image
                  src="/placeholder.svg?height=80&width=80"
                  alt="Project Image"
                  width=\{80\}
                  height=\{80\}\
                  className="rounded-lg object-cover"
                />
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">biz bir ailəyik</h3>
                  <p className="text-gray-500 dark:text-gray-400">Muzeyin dayartay yerinə mədəni tro özü</p>
                </div>
              </Card>
              <Card className="flex flex-col md:flex-row items-center p-4 gap-4">
                <Ruler className="w-20 h-20 text-gray-900 dark:text-gray-50" />
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Maarifləndirici Xatkes</h3>
                  <p className="text-gray-500 dark:text-gray-400">Maarifləndüfən alatin imkanları</p>
                </div>
              </Card>
              <Card className="flex flex-col md:flex-row items-center p-4 gap-4">
                <Flag className="w-20 h-20 text-gray-900 dark:text-gray-50" />
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Bayrağa,Sədaqət Andı</h3>
                  <p className="text-gray-500 dark:text-gray-400">Əziz xalqını təhsilinə</p>
                </div>
              </Card>
              <Card className="flex flex-col md:flex-row items-center p-4 gap-4">
                <Users className="w-20 h-20 text-gray-900 dark:text-gray-50" />
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Tədris Kursları və Sosial Aksiyalar</h3>
                  <p className="text-gray-500 dark:text-gray-400">Təhsil aksiyaları</p>
                </div>
              </Card>
            </div>
          </div>
        </section>

        <section id="about" className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Haqqında</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Komandamız və missiyamız haqqında daha çox məlumat əldə edin.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-6 py-12 lg:grid-cols-2 xl:grid-cols-2">
              <Card className="flex flex-col md:flex-row items-center p-4 gap-4">
                <Avatar className="w-24 h-24">
                  <AvatarImage src="/placeholder-user.jpg" alt="Şəraf Əhmədov" />
                  <AvatarFallback>ŞƏ</AvatarFallback>
                </Avatar>
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Şəraf Əhmədov</h3>
                  <p className="text-gray-500 dark:text-gray-400">Hüquqşünas və direktor</p>
                </div>
              </Card>
            </div>
          </div>
        </section>

        <section id="contact" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Əlaqə</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Bizimlə əlaqə saxlayın.
                </p>
              </div>
            </div>
            <div className="mx-auto w-full max-w-md py-12">
              <form className="grid gap-4">
                <Input type="text" placeholder="Ad" className="w-full" />
                <Input type="email" placeholder="Email" className="w-full" />
                <Textarea placeholder="Mesaj" className="w-full min-h-[100px]" />
                <Button type="submit" className="w-full bg-[#001f3f] text-white hover:bg-[#003366]">
                  Göndör
                </Button>
              </form>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t bg-white">
        <p className="text-xs text-gray-500 dark:text-gray-400">Əlaqə</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch=\{false\}>
            <Facebook className="h-5 w-5" />
            <span className="sr-only">Facebook</span>\
          </Link>
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch=\{false\}>
            <Instagram className="h-5 w-5" />
            <span className="sr-only">Instagram</span>\
          </Link>
        </nav>
      </footer>
    </div>
  )
\}\
